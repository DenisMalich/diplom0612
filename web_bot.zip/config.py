from werkzeug.security import generate_password_hash

# Хэш пароля администратора
ADMIN_PASSWORD_HASH = 'scrypt:32768:8:1$uC97ov81QzTDkxPK$d435c75cf3b8f54862c5816c1eafc30e74a7bcd72eb11a053345cbaf56b724efa1346349fff15f114f6c1242d7e81954be835d5102e86d38c0771333cc754148'
TOKEN_TELEGRAM = '7163658230:AAHDflOg-My2Dg3-RnOUuy3R56NjVigkNR0'
ADMIN_ID = 701768868
USER_ID = 701768868
NGROK_URL = 'https://smoothly-fun-cicada.ngrok-free.app'
recovery_code_twilio = '7XW63KPYKKZELPHVVRFXY63Z'
